const info = [
  {
    title: "Dirección",
    lines: ["97 Av. Emilio M. González Parra", "Ixtlán del Río, Nayarit, México"],
    action: {
      label: "Ver en el mapa",
      href: "https://www.google.com/maps/search/?api=1&query=Mariscos+La+Santa+Gula+Ixtlan+del+Rio+Nayarit",
    },
  },
  {
    title: "Horario",
    lines: ["Todos los días", "11:00 am – 6:00 pm"],
  },
  {
    title: "Teléfono",
    lines: ["324 243 8484"],
    action: { label: "Llamar ahora", href: "tel:3242438484" },
  },
  {
    title: "Síguenos",
    lines: ["Facebook"],
    action: { label: "Visitar Facebook", href: "https://www.facebook.com/share/1CnvbG6WXT/" },
  },
];

export function Contact() {
  return (
    <section id="contacto" className="bg-primary py-24 text-primary-foreground">
      <div className="mx-auto max-w-6xl px-5">
        <div className="text-center">
          <p className="eyebrow text-gold">Visítanos</p>
          <h2 className="mt-4 text-4xl font-600 md:text-5xl">Te esperamos</h2>
          <p className="mx-auto mt-4 max-w-xl text-lg font-300 text-primary-foreground/80">
            Ven con la familia y disfruta del mejor marisco de Ixtlán del Río.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {info.map((i) => (
            <div
              key={i.title}
              className="flex flex-col rounded-2xl border border-primary-foreground/15 bg-primary-foreground/5 p-6"
            >
              <h3 className="font-display text-2xl font-600 text-gold">{i.title}</h3>
              <div className="mt-3 flex-1 space-y-1">
                {i.lines.map((l) => (
                  <p key={l} className="font-300 text-primary-foreground/90">{l}</p>
                ))}
              </div>
              {i.action && (
                <a
                  href={i.action.href}
                  target={i.action.href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  className="mt-5 inline-block rounded-full bg-accent px-5 py-2 text-center text-sm font-500 text-accent-foreground transition-opacity hover:opacity-90"
                >
                  {i.action.label}
                </a>
              )}
            </div>
          ))}
        </div>

        <div className="mt-12 overflow-hidden rounded-2xl border border-primary-foreground/15">
          <iframe
            title="Ubicación de Mariscos La Santa Gula"
            src="https://www.google.com/maps?q=Mariscos+La+Santa+Gula+Ixtlan+del+Rio+Nayarit&output=embed"
            className="h-[360px] w-full"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}
