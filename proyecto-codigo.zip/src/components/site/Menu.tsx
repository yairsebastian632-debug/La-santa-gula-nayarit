import molcajete from "@/assets/molcajete-desgarriate.jpg";
import camarones from "@/assets/platillo-camarones.jpg";
import aguachiles from "@/assets/aguachiles.jpg";
import tostada from "@/assets/tostada-ceviche.jpg";

const dishes = [
  {
    img: molcajete,
    name: "Molcajete Desgarriate",
    tag: "El favorito",
    desc: "Camarón, pulpo, almeja y verduras servidos en molcajete caliente. Para compartir y disfrutar.",
  },
  {
    img: camarones,
    name: "Camarones a la diabla",
    tag: "Casa",
    desc: "Camarones bañados en salsa de la casa, acompañados de arroz, papas y ensalada fresca.",
  },
  {
    img: aguachiles,
    name: "Aguachiles SG",
    tag: "Refrescante",
    desc: "Camarón fresco en jugo de limón con chile, perfecto para abrir el apetito.",
  },
  {
    img: tostada,
    name: "Tostadas de ceviche",
    tag: "Del mar",
    desc: "Mariscos picados con aguacate, pepino y cítricos sobre tostada crujiente.",
  },
];

const more = [
  "Sopa marinera",
  "Pulpo a las brasas",
  "Camarones empanizados",
  "Dedos de queso (para los peques)",
  "Hamburguesas",
  "Cervezas bien frías",
];

export function Menu() {
  return (
    <section id="menu" className="bg-secondary py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div className="text-center">
          <p className="eyebrow text-accent">Lo que servimos</p>
          <h2 className="mt-4 text-4xl font-600 text-primary md:text-5xl">Nuestros platillos</h2>
          <p className="mx-auto mt-4 max-w-xl text-lg font-300 text-muted-foreground">
            Especialidades del mar preparadas al momento, con la frescura y el
            sazón que nos distinguen.
          </p>
        </div>

        <div className="mt-14 grid gap-7 sm:grid-cols-2">
          {dishes.map((d) => (
            <article
              key={d.name}
              className="group overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)]"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={d.img}
                  alt={d.name}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  width={720}
                  height={450}
                />
                <span className="absolute left-4 top-4 rounded-full bg-accent px-3 py-1 text-xs font-500 text-accent-foreground">
                  {d.tag}
                </span>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-600 text-primary">{d.name}</h3>
                <p className="mt-2 text-sm font-300 leading-relaxed text-muted-foreground">{d.desc}</p>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-gold/40 bg-card p-8">
          <h3 className="text-center text-2xl font-600 text-primary">Y mucho más en el menú</h3>
          <ul className="mx-auto mt-6 grid max-w-3xl gap-3 sm:grid-cols-2">
            {more.map((m) => (
              <li key={m} className="flex items-center gap-3 text-foreground/85">
                <span className="text-accent">◆</span>
                <span className="font-400">{m}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
