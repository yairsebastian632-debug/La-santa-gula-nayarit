import logo from "@/assets/logo-sg.png";

export function Footer() {
  return (
    <footer className="bg-background py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-5 px-5 text-center">
        <img src={logo} alt="Mariscos La Santa Gula" className="h-16 w-16 object-contain" loading="lazy" width={64} height={64} />
        <p className="font-display text-2xl font-600 text-primary">Mariscos La Santa Gula</p>
        <p className="max-w-md text-sm font-300 text-muted-foreground">
          97 Av. Emilio M. González Parra, Ixtlán del Río, Nayarit · Abierto todos
          los días 11 am – 6 pm
        </p>
        <div className="flex gap-6 text-sm font-500 text-foreground/80">
          <a href="tel:3242438484" className="hover:text-accent">324 243 8484</a>
          <a href="https://www.facebook.com/share/1CnvbG6WXT/" target="_blank" rel="noreferrer" className="hover:text-accent">Facebook</a>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">
          © {new Date().getFullYear()} Mariscos La Santa Gula. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  );
}
