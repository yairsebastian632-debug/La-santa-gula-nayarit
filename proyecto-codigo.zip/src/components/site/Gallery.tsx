import fachada from "@/assets/fachada.jpg";
import molcajeteM from "@/assets/molcajete-mariscos.jpg";
import camarones from "@/assets/platillo-camarones.jpg";
import aguachiles from "@/assets/aguachiles.jpg";
import tostada from "@/assets/tostada-ceviche.jpg";
import interior from "@/assets/interior.jpg";

const photos = [
  { src: fachada, alt: "Fachada del restaurante", span: "sm:col-span-2" },
  { src: molcajeteM, alt: "Molcajete de mariscos", span: "" },
  { src: aguachiles, alt: "Aguachiles SG", span: "" },
  { src: camarones, alt: "Platillo de camarones", span: "" },
  { src: tostada, alt: "Tostada de ceviche", span: "" },
  { src: interior, alt: "Interior del restaurante", span: "sm:col-span-2" },
];

export function Gallery() {
  return (
    <section id="galeria" className="bg-background py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div className="text-center">
          <p className="eyebrow text-accent">Galería</p>
          <h2 className="mt-4 text-4xl font-600 text-primary md:text-5xl">Sabor que se ve</h2>
        </div>
        <div className="mt-12 grid auto-rows-[220px] grid-cols-2 gap-4 sm:grid-cols-3">
          {photos.map((p) => (
            <div
              key={p.alt}
              className={`group overflow-hidden rounded-xl shadow-[var(--shadow-soft)] ${p.span}`}
            >
              <img
                src={p.src}
                alt={p.alt}
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                width={720}
                height={480}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
