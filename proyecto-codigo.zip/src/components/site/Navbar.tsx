import { useState } from "react";
import logo from "@/assets/logo-sg.png";

const links = [
  { href: "#inicio", label: "Inicio" },
  { href: "#nosotros", label: "Nosotros" },
  { href: "#menu", label: "Menú" },
  { href: "#galeria", label: "Galería" },
  { href: "#contacto", label: "Contacto" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border/40 bg-background/85 backdrop-blur-md">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
        <a href="#inicio" className="flex items-center gap-3">
          <img src={logo} alt="Mariscos La Santa Gula" className="h-11 w-11 object-contain" width={44} height={44} />
          <span className="font-display text-lg font-600 leading-none text-primary">
            La Santa Gula
          </span>
        </a>
        <ul className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="text-sm font-500 text-foreground/80 transition-colors hover:text-accent"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="tel:3242438484"
          className="hidden rounded-full bg-accent px-5 py-2 text-sm font-500 text-accent-foreground shadow-[var(--shadow-soft)] transition-opacity hover:opacity-90 md:inline-block"
        >
          Reservar
        </a>
        <button
          aria-label="Abrir menú"
          onClick={() => setOpen((o) => !o)}
          className="flex h-10 w-10 items-center justify-center rounded-md text-primary md:hidden"
        >
          <span className="text-2xl">{open ? "✕" : "☰"}</span>
        </button>
      </nav>
      {open && (
        <ul className="flex flex-col gap-1 border-t border-border/40 bg-background px-5 py-3 md:hidden">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block py-2 text-sm font-500 text-foreground/80"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      )}
    </header>
  );
}
