import interior from "@/assets/interior.jpg";

const stats = [
  { value: "100%", label: "Mariscos frescos" },
  { value: "Familiar", label: "Ambiente acogedor" },
  { value: "★★★★★", label: "Recomendado por clientes" },
];

export function About() {
  return (
    <section id="nosotros" className="bg-background py-24">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 md:grid-cols-2">
        <div className="relative">
          <img
            src={interior}
            alt="Interior familiar de Mariscos La Santa Gula"
            loading="lazy"
            className="aspect-[4/3] w-full rounded-2xl object-cover shadow-[var(--shadow-card)]"
            width={720}
            height={412}
          />
          <div className="absolute -bottom-6 -right-4 hidden rounded-xl bg-accent px-6 py-4 text-accent-foreground shadow-[var(--shadow-soft)] sm:block">
            <p className="font-display text-3xl font-600 leading-none">Santa Gula</p>
            <p className="mt-1 text-xs uppercase tracking-widest opacity-90">Beer & Tacos</p>
          </div>
        </div>
        <div>
          <p className="eyebrow text-accent">Nuestra casa</p>
          <h2 className="mt-4 text-4xl font-600 text-primary md:text-5xl">
            Un rincón marinero con sazón de familia
          </h2>
          <p className="mt-6 text-lg font-300 leading-relaxed text-muted-foreground">
            En Mariscos La Santa Gula servimos lo mejor del mar con recetas llenas
            de tradición. Nuestro ambiente es familiar y casi siempre está lleno:
            la mejor señal de que aquí se come rico.
          </p>
          <p className="mt-4 text-lg font-300 leading-relaxed text-muted-foreground">
            Desde una refrescante sopa marinera hasta nuestros molcajetes
            desbordantes de camarón y pulpo, cada platillo se prepara con frescura
            e ingredientes seleccionados. Y para los más pequeños, tenemos opciones
            pensadas para ellos.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-4">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border border-border bg-card p-4 text-center">
                <p className="font-display text-2xl font-600 text-accent">{s.value}</p>
                <p className="mt-1 text-xs font-400 text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
