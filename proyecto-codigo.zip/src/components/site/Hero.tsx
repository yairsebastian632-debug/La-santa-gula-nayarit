import hero from "@/assets/molcajete-mariscos.jpg";

export function Hero() {
  return (
    <section id="inicio" className="relative flex min-h-[100svh] items-center justify-center overflow-hidden">
      <img
        src={hero}
        alt="Molcajete de mariscos en Mariscos La Santa Gula"
        className="absolute inset-0 h-full w-full object-cover"
        width={720}
        height={568}
      />
      <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
      <div className="relative z-10 mx-auto max-w-3xl px-6 text-center text-primary-foreground">
        <p className="eyebrow text-gold">Ixtlán del Río · Nayarit</p>
        <h1 className="mt-5 text-balance text-5xl font-600 leading-[1.05] sm:text-6xl md:text-7xl">
          Mariscos La Santa Gula
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-balance text-lg font-300 text-primary-foreground/90">
          El sabor del mar con sazón casero. Frescura, tradición y un ambiente
          familiar en el corazón de Ixtlán del Río.
        </p>
        <div className="mt-9 flex flex-wrap items-center justify-center gap-4">
          <a
            href="#menu"
            className="rounded-full bg-accent px-7 py-3 text-sm font-500 text-accent-foreground shadow-[var(--shadow-soft)] transition-opacity hover:opacity-90"
          >
            Ver nuestro menú
          </a>
          <a
            href="#contacto"
            className="rounded-full border border-primary-foreground/40 px-7 py-3 text-sm font-500 text-primary-foreground transition-colors hover:bg-primary-foreground/10"
          >
            Cómo llegar
          </a>
        </div>
        <p className="mt-10 text-sm font-400 text-primary-foreground/80">
          Abierto todos los días · 11:00 am – 6:00 pm
        </p>
      </div>
    </section>
  );
}
