import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Menu } from "@/components/site/Menu";
import { Gallery } from "@/components/site/Gallery";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mariscos La Santa Gula | Ixtlán del Río, Nayarit" },
      {
        name: "description",
        content:
          "Mariscos frescos y ambiente familiar en Ixtlán del Río, Nayarit. Sopa marinera, molcajetes, aguachiles y más. Abierto todos los días de 11 am a 6 pm.",
      },
      { property: "og:title", content: "Mariscos La Santa Gula" },
      {
        property: "og:description",
        content:
          "El sabor del mar con sazón casero en Ixtlán del Río, Nayarit. Abierto todos los días 11 am – 6 pm.",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Restaurant",
          name: "Mariscos La Santa Gula",
          servesCuisine: "Mariscos",
          telephone: "+523242438484",
          address: {
            "@type": "PostalAddress",
            streetAddress: "97 Av. Emilio M. González Parra",
            addressLocality: "Ixtlán del Río",
            addressRegion: "Nayarit",
            addressCountry: "MX",
          },
          openingHours: "Mo-Su 11:00-18:00",
          sameAs: ["https://www.facebook.com/share/1CnvbG6WXT/"],
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Menu />
        <Gallery />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
